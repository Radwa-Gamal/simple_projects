
 $(document).ready(function() {
    $("body").tubular({videoId: 'fpViZkhpPHk'}); // where idOfYourVideo is the YouTube ID. 
  });